I was not sure if you were meant to have dual returns or just one, as the given pdf was rather abiguous, so naturally I've got both. The both
work almost identically.