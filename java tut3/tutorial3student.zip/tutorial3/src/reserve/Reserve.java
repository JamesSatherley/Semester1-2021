package reserve;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javafx.animation.AnimationTimer;
import javafx.application.Application;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.layout.StackPane;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.stage.Stage;

public class Reserve extends Application {

	@Override
	public void start(Stage primaryStage) throws Exception {
		// GUI Plumbing
        Group root = new Group();
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.setFullScreen(true);
        primaryStage.setTitle("Safari time!");
        primaryStage.show();

        // Set window size
        Zebra.setSize(scene.getWidth(), scene.getHeight());
        Lion.setSize(scene.getWidth(), scene.getHeight());
        Meerkat.setSize(scene.getWidth(), scene.getHeight());
        Eagle.setSize(scene.getWidth(), scene.getHeight());

        // Set finish scene
        Text message = new Text("I think we've seen enough nature for one day....");
        message.setFont(new Font(30));
        StackPane rootFinish = new StackPane();
        rootFinish.getChildren().add(message);
        rootFinish.setAlignment(Pos.CENTER);
        Scene finish = new Scene(rootFinish, 800, 600);

        // Main game loop
        new AnimationTimer() {
            private long lastUpdate = 0;
            private List<Object> animals = new ArrayList<>();
            private int meerkats = 5, eagles = 1, zebras = 3, lions = 1; // Change these for customised spawning
            private Random rand = new Random();
            
            private void addMeerkat(Meerkat a) {
            	animals.add(a);
            	root.getChildren().add(a.getView());
            }
            
            private void addEagle(Eagle a) {
            	animals.add(a);
            	root.getChildren().add(a.getView());
            }
            
            private void addZebra(Zebra a) {
            	animals.add(a);
            	root.getChildren().add(a.getView());
            }
            
            private void addLion(Lion a) {
            	animals.add(a);
            	root.getChildren().add(a.getView());
            }
            
            @Override 
            public void handle(long now) {
                // Change this to change speed (nanoseconds)
                if (now - lastUpdate > 200_000_000) {
                    lastUpdate = now;
                } else {
                    return;
                }
                
                // Spawn new animals
                for (int i = 0; i < rand.nextInt(meerkats+1); i++) {
                	Meerkat a = new Meerkat();
                	addMeerkat(a);
                }
                for (int i = 0; i < rand.nextInt(eagles+1); i++) {
                	Eagle a = new Eagle();
                	addEagle(a);
                }
                for (int i = 0; i < rand.nextInt(zebras+1); i++) {
                	Zebra a = new Zebra();
                	addZebra(a);
                }
                for (int i = 0; i < rand.nextInt(lions+1); i++) {
                	Lion a = new Lion();
                	addLion(a);
                }
                
                // Zebra and Meerkats run away from Lions and Eagles respectively
                for (Object a: animals) {
                	if (a instanceof Zebra) {
                		((Zebra) a).flee(animals);
                	} else if (a instanceof Meerkat) {
                		((Meerkat) a).flee(animals);
                	} else if (a instanceof Lion) {
                		((Lion) a).hunt(animals);
                	} else if (a instanceof Eagle) {
                		((Eagle) a).hunt(animals);
                	}
                }
                
                // Predators hunt
                List<Meerkat> deadMeerkats = new ArrayList<>();
                List<Zebra> deadZebras = new ArrayList<>();
                for (Object a: animals) {
                	if (a instanceof Lion) {
                		// Check if it killed anything
                		Zebra dead = ((Lion) a).hunt(animals);
                		if (dead != null) {
                			deadZebras.add(dead); // Save to remove at end of iteration
                			root.getChildren().remove(dead.getView()); // Remove from GUI
                		}
                		
                		// End game
                        if (((Lion) a).getKills() > 10) {
                            primaryStage.setScene(finish);
                            primaryStage.setTitle("Safari Finished!");
                            this.stop();
                        }
                	} else if (a instanceof Eagle) {
                		// Check if it killed anything
                		Meerkat dead = ((Eagle) a).hunt(animals);
                		if (dead != null) {
                			deadMeerkats.add(dead); // Save to remove at end of iteration
                			root.getChildren().remove(dead.getView()); // Remove from GUI
                		}
                		
                		// End game
                        if (((Eagle) a).getKills() > 10) {
                            primaryStage.setScene(finish);
                            primaryStage.setTitle("Safari Finished!");
                            this.stop();
                        }
                	}
                }
                
                // GC dead animals
                for (Object a: deadZebras) {
                	animals.remove(a);
                } 
                for (Object a: deadMeerkats) {
                	animals.remove(a);
                }
            }
        }.start();

	}

	public static void main(String[] args) {
		launch(args);
	}

}
