package reserve;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Zebra {
	protected ImageView view;
	
	/*
	 Static functionality
	 */
	private static Image IMAGE = loadImage("images/zebra.png");
	private static double MAX_X, MAX_Y;
	protected static Random RAND = new Random();
	
	public static void setSize(double x, double y) {
		MAX_X = x;
		MAX_Y = y;
	}

	protected static Image loadImage(String location) {
		try {
            return new Image(new FileInputStream(location));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
	}

	public Zebra() {
		view = new ImageView(IMAGE);
		
		// Set position
		view.setX(RAND.nextDouble() * MAX_X);
		view.setY(RAND.nextDouble() * MAX_Y);
		
		// Set size
		view.setFitHeight(MAX_Y / 30);
        view.setPreserveRatio(true);
	}
	
	/*
	 Game logic
	 */
	public boolean isClose(Lion other) {
		double dx = other.view.getX() - this.view.getX();
		double dy = other.view.getY() - this.view.getY();
		return hypotenuse(dx,dy) < 100;
	}

	public void randomMove() {
		view.setX(boundX(view.getX() + RAND.nextDouble() * 40 - 20));
		view.setY(boundY(view.getY() + RAND.nextDouble() * 40 - 20));
	}
	
	public void flee(List<Object> animals) {
		for (Object a: animals) {
			if (a instanceof Lion && isClose((Lion)a)) {
				moveAwayFrom((Lion)a);
				return;
			}
		}
		randomMove();
	}
	
	public void moveAwayFrom(Lion other) {
		double step = RAND.nextDouble() * 50;
		double[] normal = normalVector(other);
		view.setX(boundX(view.getX() - step * normal[0]));
		view.setY(boundY(view.getY() - step * normal[1]));
	}
	
	/*
	 Coordinate helper methods
	 Bound methods stop images from going closer than 50 pixels to the edges
	 */
	public double boundX(double proposedNumber) {
		return bound(proposedNumber, MAX_X - 50);
	}
	
	public double boundY(double proposedNumber) {
		return bound(proposedNumber, MAX_Y - 50);
	}
	
	public double bound(double proposedNumber, double max) {
		return (proposedNumber > max) ? max : (proposedNumber < 50) ? 50 : proposedNumber;
	}
	
	public double dx(Lion other) {
		return other.view.getX() - this.view.getX();
	}
	
	public double dy(Lion other) {
		return other.view.getY() - this.view.getY();
	}
	
	public double hypotenuse(double x, double y) {
		return Math.sqrt(x*x + y*y);
	}
	
	public double[] normalVector(Lion other) {
		double[] res = new double[2];
		double dx = dx(other), dy = dy(other);
		double hyp = hypotenuse(dx, dy);
		res[0] = dx/hyp;
		res[1] = dy/hyp;
		return res;
	}
	
	/*
	 Getters and Setters
	 */
	public ImageView getView() {
		return view;
	}

	public void setView(ImageView view) {
		this.view = view;
	}

}
