package reserve;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.util.List;
import java.util.Random;

import javafx.scene.image.Image;
import javafx.scene.image.ImageView;

public class Lion {
	private int kills = 0;
	protected ImageView view;
	
	/*
	 Static functionality
	 */
	private static Image IMAGE = loadImage("images/lion.png");
	private static double MAX_X, MAX_Y;
	protected static Random RAND = new Random();
	
	public static void setSize(double x, double y) {
		MAX_X = x;
		MAX_Y = y;
	}

	protected static Image loadImage(String location) {
		try {
            return new Image(new FileInputStream(location));
        } catch (FileNotFoundException e) {
            e.printStackTrace();
            return null;
        }
	}

	public Lion() {
		view = new ImageView(IMAGE);
		
		// Set position
		view.setX(RAND.nextDouble() * MAX_X);
		view.setY(RAND.nextDouble() * MAX_Y);
		
		// Set size
		view.setFitHeight(MAX_Y / 30);
        view.setPreserveRatio(true);
	}

	/*
	 Game logic
	 */
	public Zebra hunt(List<Object> animals) {
		for (Object a: animals) {
			if (a instanceof Zebra && isClose((Zebra)a)) {
				Zebra b = (Zebra)a;
				chase(b);
				if (preyCaught(b)) {
					kills++;
					return b;
				}
				return null; // Only chase once per turn
			}
		}
		randomMove();
		return null;
	}
	
	public boolean isClose(Zebra other) {
		double dx = other.view.getX() - this.view.getX();
		double dy = other.view.getY() - this.view.getY();
		return hypotenuse(dx,dy) < 100;
	}

	public void randomMove() {
		view.setX(boundX(view.getX() + RAND.nextDouble() * 40 - 20));
		view.setY(boundY(view.getY() + RAND.nextDouble() * 40 - 20));
	}
	
	public void chase(Zebra other) {
		double step = RAND.nextDouble() * 50;
		double[] normal = normalVector(other);
		
		// Don't overshoot the prey
		double distanceX = (step*normal[0] < dx(other)) ? dx(other) : step*normal[0];
		double distanceY = (step*normal[1] < dy(other)) ? dy(other) : step*normal[1];
		
		view.setX(boundX(view.getX() + distanceX));
		view.setY(boundY(view.getY() + distanceY));
	}
	
	public boolean preyCaught(Zebra other) {
		return hypotenuse(dx(other), dy(other)) < 10;
	}
	
	
	/*
	 Coordinate helper methods
	 Bound methods stop images from going closer than 50 pixels to the edges
	 */
	public double boundX(double proposedNumber) {
		return bound(proposedNumber, MAX_X - 50);
	}
	
	public double boundY(double proposedNumber) {
		return bound(proposedNumber, MAX_Y - 50);
	}
	
	public double bound(double proposedNumber, double max) {
		return (proposedNumber > max) ? max : (proposedNumber < 50) ? 50 : proposedNumber;
	}
	
	public double dx(Zebra other) {
		return other.view.getX() - this.view.getX();
	}
	
	public double dy(Zebra other) {
		return other.view.getY() - this.view.getY();
	}
	
	public double hypotenuse(double x, double y) {
		return Math.sqrt(x*x + y*y);
	}
	
	public double[] normalVector(Zebra other) {
		double[] res = new double[2];
		double dx = dx(other), dy = dy(other);
		double hyp = hypotenuse(dx, dy);
		res[0] = dx/hyp;
		res[1] = dy/hyp;
		return res;
	}
	

	/*
	 Getters and Setters
	 */
	public ImageView getView() {
		return view;
	}

	public void setView(ImageView view) {
		this.view = view;
	}
	
	public int getKills() {
		return kills;
	}

	public void setKills(int kills) {
		this.kills = kills;
	}
}
