I have included and automatic batch file to run the cmd compile command listed below. This will compile the zipped file which is exported as a jar file
The generated index.html is the given args in the batch file. You can open a cmd here and enter the command listed below to demonstrate. I hope this is
okay as the "deliverable" were somewhat ambiguous.


.bat file:

java -jar compiled.jar students.csv index.html