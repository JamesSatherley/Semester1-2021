possible = [1,2,3,4,5,6,7,8,9]
colcells = [1,0,3,2,5,0,7,8,9]
print([item in possible for item in colcells])