Check is not enforced and cannot check for complicated constraints 

I apologise for how bad this tutorial is, been very busy, will be better in the future
