PLEASE USE THE PLAYERS.TXT AND TEAMS.TXT I HAVE INCLUDED. Your ones had some extra random spaces (" ") that I assume were and error when copy and pasting
the text files from web or the like.