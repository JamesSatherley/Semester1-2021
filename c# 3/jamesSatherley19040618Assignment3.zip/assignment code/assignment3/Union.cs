﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace assignment3
{
    class Union
    {
        public List<Team> Teams { get; set; } // unused, should be used.. oopsie

        public Union(List<Team> team)
        {
            Teams = team;
        }

        public void AddStringTeam(string team)
        { 
            
        }
    }
}
