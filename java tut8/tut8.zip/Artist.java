public class Artist {
	
	private String name;
	private String country;
	private String band;

	public Artist(String name, String country, String band) {
		this.name = name;
		this.country = country;
		this. band = band;
	}
	
	public String getName() { return name;}
	public String isFrom() {return country;}
	
}