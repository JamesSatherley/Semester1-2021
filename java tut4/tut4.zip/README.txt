I have included and automatic batch file to run the cmd compile commands listed below. This will compile the tut4 jar file.

.bat file:

java -jar compiled_tut4.jar students.csv by_id sorted_students_id.csv
java -jar compiled_tut4.jar students.csv by_firstname sorted_students_firstname.csv
java -jar compiled_tut4.jar students.csv by_lastname sorted_students_lastname.csv
java -jar compiled_tut4.jar students.csv by_program sorted_students_program.csv
java -jar compiled_tut4.jar students.csv by_id students.csv
PAUSE